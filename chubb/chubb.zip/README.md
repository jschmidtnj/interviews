# 3 number sort

> sort array with 3 unique numbers (typescript)
